const params = {
  email: { type: 'email' }
}

module.exports = params
