module.exports = {
  name: 'PolagramUser',
  connect: require('./connect'),
  attributes: require('./attributes'),
  options: require('./options')
}
