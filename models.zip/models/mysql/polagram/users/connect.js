const nconf = require('nconf')
nconf.argv().env().file({ file: 'nconf.json' })

module.exports = {
  dialect: 'mysql',
  database: 'polagram',
  hostname: nconf.get('APP_POLAGRAM_HOSTNAME') || 'localhost',
  port: 3306,
  username: nconf.get('APP_POLAGRAM_USERNAME') || 'infra',
  password: nconf.get('APP_POLAGRAM_PASSWORD') || 'infra'
}
