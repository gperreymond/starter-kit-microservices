const options = {
  tableName: 'users',
  timestamps: false
}

module.exports = options
