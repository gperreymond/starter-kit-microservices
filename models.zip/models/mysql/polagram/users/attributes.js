const Sequelize = require('sequelize')

module.exports = {
  user_id: {
    type: Sequelize.INTEGER(11).UNSIGNED,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  email: {
    type: Sequelize.STRING(255),
    allowNull: false,
    unique: true
  },
  pg_code: {
    type: Sequelize.STRING(50),
    allowNull: true
  },
  datecreation: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  password: {
    type: Sequelize.STRING(100),
    allowNull: true
  },
  salt: {
    type: Sequelize.STRING(25),
    allowNull: true
  },
  referral_pot: {
    type: Sequelize.FLOAT,
    allowNull: false,
    defaultValue: '0.00'
  },
  former_pot: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  reward_pot: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  support_pot: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  giftcard_pot: {
    type: Sequelize.FLOAT,
    allowNull: false,
    defaultValue: '0.00'
  },
  pot_expiry: {
    type: Sequelize.DATEONLY,
    allowNull: true
  },
  giftcard_expiry: {
    type: Sequelize.DATEONLY,
    allowNull: true
  },
  lang: {
    type: Sequelize.STRING(12),
    allowNull: true,
    defaultValue: 'en'
  },
  app_version: {
    type: Sequelize.STRING(80),
    allowNull: true
  },
  fb_id: {
    type: Sequelize.BIGINT,
    allowNull: true
  },
  birthday: {
    type: Sequelize.DATEONLY,
    allowNull: true
  },
  gender: {
    type: Sequelize.STRING(3),
    allowNull: true
  },
  total_revenues: {
    type: Sequelize.FLOAT,
    allowNull: false,
    defaultValue: '0.00'
  },
  currency: {
    type: Sequelize.STRING(3),
    allowNull: false,
    defaultValue: 'EUR'
  },
  gplus_id: {
    type: Sequelize.INTEGER(11).UNSIGNED,
    allowNull: true
  },
  apple_push_id: {
    type: Sequelize.STRING(255),
    allowNull: true
  },
  UDID: {
    type: Sequelize.STRING(70),
    allowNull: true
  },
  user_first_name: {
    type: Sequelize.STRING(50),
    allowNull: true
  },
  user_last_name: {
    type: Sequelize.STRING(50),
    allowNull: true
  },
  unsubscribed: {
    type: Sequelize.INTEGER(1),
    allowNull: false,
    defaultValue: '0'
  },
  comments: {
    type: Sequelize.TEXT,
    allowNull: true
  },
  token_generate: {
    type: Sequelize.STRING(50),
    allowNull: true
  },
  token_saved: {
    type: Sequelize.STRING(20),
    allowNull: true
  },
  bt_customer_id: {
    type: Sequelize.STRING(50),
    allowNull: true
  },
  country: {
    type: Sequelize.CHAR(2),
    allowNull: true
  },
  optins: {
    type: Sequelize.JSON,
    allowNull: true
  }
}
